import xbmcaddon

MainBase = 'http://bit.ly/KeltecMP-venha/'
addon = xbmcaddon.Addon('plugin.video.KeltecMP')