import xbmcaddon

MainBase = 'https://pastebin.com/raw/5bBW67Yf'
addon = xbmcaddon.Addon('plugin.video.netfreeplay')